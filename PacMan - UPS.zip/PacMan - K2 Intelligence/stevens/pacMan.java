package stevens;
import java.applet.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.*;
import java.util.Random;
public class pacMan extends runApplet implements KeyListener
{
	Random gen = new Random();
	//Variables for Pac Man
	int pacX = 275,pacY = 275,pacXspeed = 0,pacYspeed = 0;
	//Variables for Inky
	int inkyX = 275,inkyY = 275,inkyXSpeed = 2,inkyYSpeed =-2;
	//Variables for Pinky
	int pinkyX = 275,pinkyY = 275,pinkyXSpeed = -2,pinkyYSpeed = 2;
	//Variables for Blinky
	int blinkyX = 275,blinkyY = 275,blinkyXSpeed = 2,blinkyYSpeed = 2;
	//Variables for Clyde
	int clydeX = 275,clydeY = 275,clydeXSpeed = -2,clydeYSpeed = -2;
	//Variables for Pac-Dots, Pellet and Fruits
	int dot1X = 60,dot1Y = 85,dot2X = 510,dot2Y = 85,dot3X = 60;
	int dot3Y=495,dot4X=510,dot4Y=495,pelletX=285,pelletY=200;
	int fruitX=275,fruitY=400;
	//Variables for Animations
	int dir = 0,mouth;
	//Game Values
	int score = 0,count=0,time=0,fruitNumber=0;
	String ghostCollided;
	//Hi-Score Info (must be altered in code)
	String hsInitials = ("KEM");
	int highScore = 35400;
	String filename = "PacmanScores.txt";
	String line = null;
	//Timer variables
	int startCount = 0; //counter for intro theme
	int startTime = 0; //time for intro theme
	int bgmCount = 0; //counter to help BGM loop correctly
	int minuteCount = 0; //counter for minute calculation
	int minuteTime = 0; //time for minute calculation
	int minutehalfCount = 0; //counter for minute and a half calculation
	int minutehalfTime = 0; //timer for minute and a half calculation
	int pelletCount = 0; //counter for power pellet spawn
	int pelletTime = 0; //time for power pellet spawn
	int fruitCount = 0; //counter for fruit spawn
	int fruitTime = 0; //time for fruit spawn
	int scaredCount = 0; //counter for pellet duration
	int scaredTime = 0; //time for pellet duration
	int scareCount = 0; //counter for scared theme
	int scareAlarmCount = 0; //counter for unscare alarm theme
	int spawnCount = 0; //counter for ghost respawn
	int spawnTime = 0; //time for ghost respawn
	//Booleans
	boolean showStart = true; //shows start screen
	boolean playGame = false; //shows the game
	boolean gameOver = false; //shows game over screen
	boolean scores = false;
	boolean opening = true; // tells if mouth is opening (for animation)
	boolean dying = false; //for death animation
	boolean upDown; //checks if going up or down
	boolean goUp; //checks if going up
	boolean leftRight; //checks if going left of right
	boolean goRight; //checks if going right
	boolean startMovement; //prevents pacman from moving until key press
	boolean startPlay; //checks for  when start theme is playing
	boolean bgmPlay; //checks for when BGM is playing
	boolean scaredPlay; //checks for when scared theme is playing
	boolean unscarePlay; //checks for when unscare alarm theme is playing
	boolean showHitBoxes; //developer feature - outlines solid objects (s - on, d- off)
	boolean minute; //checks for minute integrals
	boolean minutehalf; // checks for minute and a half integrals
	boolean pelletActive; //checks if the power pellet is in play
	boolean fruitActive; //checks if the fruit is in play
	boolean scared; //checks if ghosts are under the influence of power pellet
	boolean inkMunched; //checks if munched
	boolean pinkMunched; //checks if munched
	boolean blinkMunched; //checks if munched
	boolean clydeMunched; //checks if munched
	boolean ghostsRespawning; //checks for ghost respawns
	//Solid Objects
	SolidObject pacSO = new SolidObject();
	SolidObject dot1SO = new SolidObject();
	SolidObject dot2SO = new SolidObject();
	SolidObject dot3SO = new SolidObject();
	SolidObject dot4SO = new SolidObject();
	SolidObject ppSO = new SolidObject();
	SolidObject fruitSO = new SolidObject();
	SolidObject inkySO = new SolidObject();
	SolidObject pinkySO = new SolidObject();
	SolidObject blinkySO = new SolidObject();
	SolidObject clydeSO = new SolidObject();
	//Font
	Font big = new Font(Font.SERIF,Font.BOLD,50);
	Font medium = new Font(Font.SERIF,Font.BOLD,25);
	Font small = new Font(Font.SERIF,Font.BOLD,15);
	//Images
	Image inky,pinky,blinky,clyde,start,background,gameover;
	Image ghostscared,cherry,strawberry,orange,apple,melon,galaxian,bell,key;
	//Sounds
	AudioClip pacStart,pacBGM,pacMunch,pacDeath,ghostScared;
	AudioClip ghostUnscareAlarm,ghostMunch,fruitMunch;
	//Initializes the game with a Key Listener
	public void init()
	{
		addKeyListener(this);
		//Gets image files
		inky = getImage(getCodeBase(), "inky.jpg");
		pinky = getImage(getCodeBase(), "pinky.jpg");
		blinky = getImage(getCodeBase(), "blinky.jpg");
		clyde = getImage(getCodeBase(), "clyde.jpg");
		start = getImage(getCodeBase(), "title.jpg");
		background = getImage(getCodeBase(),"maze.jpg");
		gameover = getImage(getCodeBase(), "gameOver.jpg");
		ghostscared = getImage(getCodeBase(), "scared.jpg");
		cherry = getImage(getCodeBase(), "cherry.jpg");
		strawberry = getImage(getCodeBase(), "strawberry.jpg");
		orange = getImage(getCodeBase(), "orange.jpg");
		apple = getImage(getCodeBase(), "apple.jpg");
		melon = getImage(getCodeBase(), "melon.jpg");
		galaxian = getImage(getCodeBase(), "galaxian.jpg");
		bell = getImage(getCodeBase(), "bell.jpg");
		key = getImage(getCodeBase(), "key.jpg");
		//Gets sound files
		pacStart = getAudioClip(getCodeBase(), "pacStart.wav");
		pacBGM = getAudioClip(getCodeBase(), "pacBGM.wav");
		pacMunch = getAudioClip(getCodeBase(), "pacMunch.wav");
		pacDeath = getAudioClip(getCodeBase(), "pacDeath.wav");
		ghostScared = getAudioClip(getCodeBase(), "ghostScared.wav");
		ghostUnscareAlarm = getAudioClip(getCodeBase(), "ghostUnscareAlarm.wav");
		ghostMunch = getAudioClip(getCodeBase(), "ghostMunch.wav");
		fruitMunch = getAudioClip(getCodeBase(), "fruitMunch.wav");
	}
	//Draws the Start Screen
	public void startScreen(Graphics art)
	{
		art.drawImage(start,0,0,600,600,this);
		art.setColor(Color.white);
		art.setFont(medium);
		art.drawString("Created By Kyle McShea",40,180);
		art.setFont(small);
		art.drawString("Controls -",20,310);
		art.drawString("Up Arrow Key - Moves Pac-Man upwards",30,330);
		art.drawString("Down Arrow Key - Moves Pac-Man downwards",30,350);
		art.drawString("Left Arrow Key - Moves Pac-Man left",30,370);
		art.drawString("Right Arrow Key - Moves Pac-Man Right",30,390);
		art.drawString("Rules -",20,420);
		art.drawString("Collect Pac-dots, 100 points each",30,440);
		art.drawString("More ghosts will spawn the longer the game plays (Once every 15 seconds)",30,460);
		art.drawString("Ghosts will blink 3 times upon spawning, they become active after the 4th time",30,480);
		art.drawString("Hitting a ghost will result in game over",30,500);
		art.drawString("Power Pellets spawn every minute for 4 seconds",30,520);
		art.drawString("Hitting a ghost while a Power Pellet is active grants 500 pts",30,540);
		art.drawString("Fruits spawn every 90 seconds, granting increasing points per fruit collected",30,560);
		art.drawString("Press [Enter] to begin",225,580);
	}
	//Draws Pacman
	public void drawPacman(Graphics art)
	{
		art.setColor(Color.yellow);
		art.fillArc(pacX,pacY,50,50, dir + mouth , 360 - (mouth * 2));
		if(opening)
			mouth+=5;
		else
			mouth-=5;
		if(mouth > 45 || mouth < 0)
			opening = !opening;
		pacSO.makeSolidObject(pacX + 8,pacY + 8,32,32);
		if(showHitBoxes)
		{
			art.setColor(Color.red);
			art.drawRect(pacX + 8,pacY + 8,32,32);
		}
		 movePac();
	}
	//Moves Pacman
	public void movePac()
	{
		if(startTime >= 5)
		{
			if(startMovement)
			{
				if(upDown)   //when going up or down
				{
					if(goUp)    //going up
					{
						if(pacY > 55)   //inbounds
							pacYspeed = -3;
						else
							pacYspeed = 0;  //hit top wall
					}
					else
					{
						if(pacY < 495)   //inbounds
							pacYspeed = 3;
						else
							pacYspeed = 0;   //hit bottom wall
					}
				}
				else    //when going left right
				{
					if(goRight)
					{
						if(pacX < 520) //inbounds
							pacXspeed = 3;
						else
							pacXspeed = 0;	//hit right wall
					}
					else
					{
						if(pacX > 30) //inbounds
							pacXspeed = -3;
						else
							pacXspeed = 0; //hit left wall
					}
				}
			}
		}				
		pacX = pacX + pacXspeed;	
		pacY = pacY + pacYspeed;
	}
	//Draws Inky
	public void drawInky(Graphics art)
	{
		if(time == 9 || time == 11 || time ==13)
		{
			art.drawImage(inky,inkyX,inkyY,50,50,this);
		}
		
		if(time >= 15)
		{
			if(!inkMunched)
			{
				inkySO.makeSolidObject(inkyX + 8,inkyY + 8,32,32);
				if(!scared)
				{
					art.drawImage(inky,inkyX,inkyY,50,50,this);
				}
				else
				{
					art.drawImage(ghostscared,inkyX,inkyY,50,50,this);	
				}
			
				if(showHitBoxes)
				{
					art.setColor(Color.red);
					art.drawRect(inkyX + 8,inkyY + 8,32,32);
				}
				moveInky();
			}
			else
			{
				inkySO.makeSolidObject(600,600,32,32);
			}
		}
		if(time <15)
		{
			art.drawImage(inky,600,600,50,50,this);
			inkySO.makeSolidObject(600,600,32,32);
		}
	}
	//Moves Inky
	public void moveInky()
	{
		inkyX = inkyX + inkyXSpeed;
		inkyY = inkyY + inkyYSpeed;
		if(inkyX <= 30 || inkyX >= 520)
		{
			inkyXSpeed = -(inkyXSpeed);
		}
		if(inkyY <= 55 || inkyY >= 495)
		{
			inkyYSpeed = -(inkyYSpeed);
		}
		if(scaredCount == 1)
		{
			inkyXSpeed = -(inkyXSpeed);
			inkyYSpeed = -(inkyYSpeed);
		}
	}
	//Draws Pinky
	public void drawPinky(Graphics art)
	{
		if(time == 24 || time == 26 || time == 28)
		{
			art.drawImage(pinky,pinkyX,pinkyY,50,50,this);
		}
		if(time >= 30)
		{
			if(!pinkMunched)
			{
				pinkySO.makeSolidObject(pinkyX + 8,pinkyY + 8,32,32);
				if(!scared)
				{
					art.drawImage(pinky,pinkyX,pinkyY,50,50,this);
				}
				else
				{
					art.drawImage(ghostscared,pinkyX,pinkyY,50,50,this);
				}
			
				if(showHitBoxes)
				{
					art.setColor(Color.red);
					art.drawRect(pinkyX + 8,pinkyY + 8,32,32);
				}
				movePinky();
			}
			else
			{
				pinkySO.makeSolidObject(600,600,32,32);
			}
		}
		if(time <30)
		{
			art.drawImage(pinky,600,600,50,50,this);
			pinkySO.makeSolidObject(600,600,32,32);
		}
	}
	//Moves Pinky
	public void movePinky()
	{
		pinkyX = pinkyX + pinkyXSpeed;
		pinkyY = pinkyY + pinkyYSpeed;
		if(pinkyX <= 30 || pinkyX >= 520)
		{
			pinkyXSpeed = -(pinkyXSpeed);
		}
		if(pinkyY <= 55 || pinkyY >= 495)
		{
			pinkyYSpeed = -(pinkyYSpeed);
		}
		
		if(scaredCount == 1)
		{
			pinkyXSpeed = -(pinkyXSpeed);
			pinkyYSpeed = -(pinkyYSpeed);
		}
	}
	//Draws Blinky
	public void drawBlinky(Graphics art)
	{
		if(time == 39 || time == 41 || time == 43)
		{
			art.drawImage(blinky,blinkyX,blinkyY,50,50,this);
		}
		if(time >= 45)
		{
			if(!blinkMunched)
			{
				blinkySO.makeSolidObject(blinkyX + 8,blinkyY + 8,32,32);
				if(!scared)
				{
					art.drawImage(blinky,blinkyX,blinkyY,50,50,this);
				}
				else
				{
					art.drawImage(ghostscared,blinkyX,blinkyY,50,50,this);
				}
				if(showHitBoxes)
				{
					art.setColor(Color.red);
					art.drawRect(blinkyX + 8,blinkyY + 8,32,32);
				}
				moveBlinky();
			}
			else
			{
				blinkySO.makeSolidObject(600,600,32,32);
			}
		}
		if(time <45)
		{
			art.drawImage(blinky,600,600,50,50,this);
			blinkySO.makeSolidObject(600,600,32,32);
		}
	}
	//Moves Blinky
	public void moveBlinky()
	{
		blinkyX = blinkyX + blinkyXSpeed;
		blinkyY = blinkyY + blinkyYSpeed;
		if(blinkyX <= 30 || blinkyX >= 520)
		{
			blinkyXSpeed = -(blinkyXSpeed);
		}
		if(blinkyY <= 55 || blinkyY >= 495)
		{
			blinkyYSpeed = -(blinkyYSpeed);
		}
		if(scaredCount == 1)
		{
			blinkyXSpeed = -(blinkyXSpeed);
			blinkyYSpeed = -(blinkyYSpeed);
		}
	}
	//Draws Clyde
	public void drawClyde(Graphics art)
	{
		if(time == 54 || time == 56 || time == 58)
		{
			art.drawImage(clyde,clydeX,clydeY,50,50,this);
		}
		if(time >= 60)
		{
			if(!clydeMunched)
			{
				clydeSO.makeSolidObject(clydeX + 8,clydeY + 8,32,32);
				if(!scared)
				{
					art.drawImage(clyde,clydeX,clydeY,50,50,this);
				}
				else
				{
					art.drawImage(ghostscared,clydeX,clydeY,50,50,this);
				}
				if(showHitBoxes)
				{
					art.setColor(Color.red);
					art.drawRect(clydeX + 8,clydeY + 8,32,32);
				}
				moveClyde();
			}
			else
			{
				clydeSO.makeSolidObject(600,600,32,32);	
			}
		}
		if(time <60)
		{
			art.drawImage(clyde,600,600,50,50,this);
			clydeSO.makeSolidObject(600,600,32,32);
		}
	}
	//Moves Clyde
	public void moveClyde()
	{
		clydeX = clydeX + clydeXSpeed;
		clydeY = clydeY + clydeYSpeed;
		if(clydeX <= 30 || clydeX >= 520)
		{
			clydeXSpeed = -(clydeXSpeed);
		}
		if(clydeY <= 55 || clydeY >= 495)
		{
			clydeYSpeed = -(clydeYSpeed);
		}
		if(scaredCount == 1)
		{
			clydeXSpeed = -(clydeXSpeed);
			clydeYSpeed = -(clydeYSpeed);
		}
	}
	//Draws dot 1
	public void drawDot1(Graphics art)
	{
		art.setColor(Color.yellow);
		art.fillOval(dot1X,dot1Y,20,20);
		dot1SO.makeSolidObject(dot1X + 3, dot1Y + 3,14,14);
		if(showHitBoxes)
		{
			art.setColor(Color.red);
			art.drawRect(dot1X + 3, dot1Y + 3,14,14);
		}
	}
	//Draws dot 2
	public void drawDot2(Graphics art)
	{
		art.setColor(Color.yellow);
		art.fillOval(dot2X,dot2Y,20,20);
		dot2SO.makeSolidObject(dot2X + 3, dot2Y + 3,14,14);
		if(showHitBoxes)
		{
			art.setColor(Color.red);
			art.drawRect(dot2X + 3, dot2Y + 3,14,14);
		}
	}
	//Draws dot 3
	public void drawDot3(Graphics art)
	{
		art.setColor(Color.yellow);
		art.fillOval(dot3X,dot3Y,20,20);
		dot3SO.makeSolidObject(dot3X + 3, dot3Y + 3,14,14);
		if(showHitBoxes)
		{
			art.setColor(Color.red);
			art.drawRect(dot3X + 3, dot3Y + 3,14,14);
		}
	}
	//Draws dot 4
	public void drawDot4(Graphics art)
	{
		art.setColor(Color.yellow);
		art.fillOval(dot4X,dot4Y,20,20);
		dot4SO.makeSolidObject(dot4X + 3, dot4Y + 3,14,14);
		
		if(showHitBoxes)
		{
			art.setColor(Color.red);
			art.drawRect(dot4X + 3, dot4Y + 3,14,14);
		}
	}
	//draws the power pellet
	public void drawPP(Graphics art)
	{
		if(pelletActive)
		{
			art.setColor(Color.yellow);
			art.fillOval(pelletX,pelletY,30,30);
			ppSO.makeSolidObject(pelletX + 5,pelletY + 5,20,20);
			if(showHitBoxes)
			{
				art.setColor(Color.red);
				art.drawRect(pelletX + 5,pelletY + 5,20,20);
			}
		}
		else
		{
			art.setColor(Color.yellow);
			art.fillOval(600, 600, 30, 30);
			ppSO.makeSolidObject(600,600,30,30);
		}
	}
	//Draws the fruits
	public void drawFruit(Graphics art)
	{
		if(fruitActive)
		{
			fruitSO.makeSolidObject(fruitX + 10,fruitY + 10,30,30);
			if(fruitNumber == 0)
				art.drawImage(cherry,fruitX,fruitY,50,50,this);
			if(fruitNumber == 1)
				art.drawImage(strawberry,fruitX,fruitY,50,50,this);
			if(fruitNumber == 2)
				art.drawImage(orange,fruitX,fruitY,50,50,this);
			if(fruitNumber == 3)
				art.drawImage(apple,fruitX,fruitY,50,50,this);
			if(fruitNumber == 4)
				art.drawImage(melon,fruitX,fruitY,50,50,this);
			if(fruitNumber == 5)
				art.drawImage(galaxian,fruitX,fruitY,50,50,this);
			if(fruitNumber == 6)
				art.drawImage(bell,fruitX,fruitY,50,50,this);
			if(fruitNumber >= 7)
				art.drawImage(key,fruitX,fruitY,50,50,this);
			if(showHitBoxes)
			{
				art.setColor(Color.red);
				art.drawRect(fruitX + 10,fruitY + 10,30,30);
			}
		}
		else
		{
			art.drawImage(cherry,600,600,50,50,this);
			fruitSO.makeSolidObject(600,600,30,30);
		}
	}
	//Draws the arena
	public void drawArena(Graphics art)
	{
		art.drawImage(background,0,0,600,600,this);
		art.setColor(Color.blue);
		art.drawRect(25,50,550,500);
		art.drawRect(30,55,540,490);
		art.setColor(Color.white);
		art.setFont(medium);
		art.drawString("Pac-Man - by Definitely Not Namco",135,30);
		art.drawString("Score - "+score+" pts.",25,575);
		art.drawString("Time - "+time+" seconds",375,575);
		if(startTime <= 4)
		{
			art.drawString("Get Ready!",240,100);
		}
		if(startTime == 5)
		{
			art.drawString("Go!", 280, 100);
		}
	}
	//Checks for collisions
	public void collision()
	{
		//Dot, Pellet and Fruit collisions
		if(pacSO.isCollidingWith(dot1SO))
		{
			score = score + 100;
			dot1X = gen.nextInt(451) + 60;
			dot1Y = gen.nextInt(411) + 85;
			pacMunch.play();
		}
		if(pacSO.isCollidingWith(dot2SO))
		{
			score = score + 100;
			dot2X = gen.nextInt(451) + 60;
			dot2Y = gen.nextInt(411) + 85;
			pacMunch.play();
		}
		if(pacSO.isCollidingWith(dot3SO))
		{
			score = score + 100;
			dot3X = gen.nextInt(451) + 60;
			dot3Y = gen.nextInt(411) + 85;
			pacMunch.play();
		}
		if(pacSO.isCollidingWith(dot4SO))
		{
			score = score + 100;
			dot4X = gen.nextInt(451) + 60;
			dot4Y = gen.nextInt(411) + 85;
			pacMunch.play();
		}
		if(pacSO.isCollidingWith(ppSO))
		{
			scared = true;
			pelletActive = false;
		}
		if(pacSO.isCollidingWith(fruitSO))
		{
			fruitNumber++;
			fruitActive = false;
			fruitMunch.play();
			if(fruitNumber == 1)
				score = score + 1000;
			if(fruitNumber == 2)
				score = score + 2000;
			if(fruitNumber == 3)
				score = score + 3000;
			if(fruitNumber == 4)
				score = score + 4000;
			if(fruitNumber == 5)
				score = score + 5000;
			if(fruitNumber == 6)
				score = score + 6000;
			if(fruitNumber == 7)
				score = score + 7000;
			if(fruitNumber >= 8)
				score = score + 8000;
		}
		//Ghost collision cases
		if(pacSO.isCollidingWith(inkySO))
		{
			if(!scared)
			{
				playGame = false;
				gameOver = true;
				dying = true;
				ghostCollided = ("Inky");
				pacBGM.stop();
				pacDeath.play();
			}
			else
			{
				score = score + 1000;
				inkMunched = true;
				ghostMunch.play();
			}
		}
		if(pacSO.isCollidingWith(pinkySO))
		{
			if(!scared)
			{
				playGame = false;
				gameOver = true;
				dying = true;
				ghostCollided = ("Pinky");
				pacBGM.stop();
				pacDeath.play();
			}
			else
			{
				score = score + 1000;
				pinkMunched = true;
				ghostMunch.play();
			}
		}
		if(pacSO.isCollidingWith(blinkySO))
		{
			if(!scared)
			{
				playGame = false;
				gameOver = true;
				dying = true;
				ghostCollided = ("Blinky");
				pacBGM.stop();
				pacDeath.play();
			}
			else
			{
				score = score + 1000;
				blinkMunched = true;
				ghostMunch.play();
			}
		}
		if(pacSO.isCollidingWith(clydeSO))
		{
			if(!scared)
			{
				playGame = false;
				gameOver = true;
				dying = true;
				ghostCollided = ("Clyde");
				pacBGM.stop();
				pacDeath.play();
			}
			else
			{
				score = score + 1000;
				clydeMunched = true;
				ghostMunch.play();
			}
		}
	} 
	//Draws the Game Over Screen
	public void endScreen(Graphics art)
	{
		if(!scores)
		{
			art.drawImage(gameover,0,0,600,600,this);
			art.setFont(big);
			art.setColor(Color.white);
			art.drawString("Game Over", 175, 100);
			art.setFont(medium);
			if(score < highScore)
			{
				art.drawString("Hi - Score", 50, 200);
				art.drawString(""+hsInitials+" ", 200, 200);
				art.drawString(""+highScore+" pts.", 300, 200);
			}
			else
			{
				art.drawString("New Hi-Score!     Notify Sean Kunz to update Hi-Score", 50, 200);
			}
			art.drawString("You collided with "+ghostCollided+" ", 50, 300);
			if(ghostCollided.equals("Inky"))
				art.drawImage(inky, 340, 255, 50, 50,this);
			if(ghostCollided.equals("Pinky"))
				art.drawImage(pinky, 340, 255, 50, 50,this);
			if(ghostCollided.equals("Blinky"))
				art.drawImage(blinky, 340, 255, 50, 50,this);
			if(ghostCollided.equals("Clyde"))
				art.drawImage(clyde, 340, 255, 50, 50,this);
			art.drawString("You lasted "+time+" seconds", 50, 400);
			art.drawString("Your score was "+score+" pts.", 50, 450);
			art.setFont(small);
		}
	}
	//Timer
	public void timer()
	{
		if(startTime >= 5)
		{
			//Regular game time
			count++;
			time = count / 60;
			//Minute timer for Power Pellets
			minuteCount++;
			minuteTime = minuteCount / 60;
			if(minuteTime == 60)
			{
				minute = true;
			}
			if(minuteCount == 3601)
			{
				minuteCount = 0;
				minuteTime = 0;
				minute = false;
			}
			//Timer for pellet active
			if(minute)
			{
				pelletActive = true;
			}
			
			if(pelletActive)
			{
				pelletCount++;
				pelletTime = pelletCount / 60;
			}
			if(pelletTime == 6)
			{
				pelletActive = false;
				pelletCount = 0;
				pelletTime = 0;
			}
			//Minute and a half timer for Fruits
			minutehalfCount++;
			minutehalfTime = minutehalfCount / 60;
			if(minutehalfTime == 90)
			{
				minutehalf = true;
			}
			if(minutehalfCount == 5401)
			{
				minutehalfCount = 0;
				minutehalfTime = 0;
				minutehalf = false;
			}
			//Timer for fruit active
			if(minutehalf)
			{
				fruitActive = true;
			}
			if(fruitActive)
			{
				fruitCount++;
				fruitTime = fruitCount / 60;
			}
			if(fruitTime == 6)
			{
				fruitActive = false;
				fruitCount = 0;
				fruitTime = 0;
			}
			//Timer for power pellet duration
			if(scared)
			{
				scaredCount++;
				scaredTime = scaredCount / 60;
			}
			if(scaredTime == 5)
			{
				scared = false;
				scaredCount = 0;
				scaredTime = 0;
				ghostsRespawning = true;
				resetGhosts();
			}
			//Timer for ghost respawn
			if(ghostsRespawning)
			{
				spawnCount++;
				spawnTime = spawnCount / 60;
			}
			if(spawnTime == 5)
			{
				ghostsRespawning = false;
				spawnCount = 0;
				spawnTime = 0;
			}
		}	
	}
	//Intro music
	public void startMusic()
	{
		if(!startPlay)
		{
			pacStart.play();
			startPlay = true;
		}
		startCount++;
		startTime = startCount / 60;
	}
	//Background Music
	public void bgm()
	{
		if(startTime > 5)
		{
			if(!scared)
			{
				if(!bgmPlay)
				{
					pacBGM.play();
					bgmPlay = true;
					bgmCount = 0;
				}
				if(bgmPlay)
				{
					bgmCount++;
				}
				
				if(bgmCount == 110)
				{
					bgmPlay = false;
				}
			}
			else
			{
				pacBGM.stop();
				bgmPlay = false;
				if(scaredTime < 3)
				{
					if(!scaredPlay)
					{
						ghostScared.play();
						scaredPlay = true;
						scareCount = 0;
					}
					if(scaredPlay)
					{
						scareCount++;
					}
					if(scareCount == 50)
					{
						scaredPlay = false;
					}
				}
				else
				{
					if(!unscarePlay)
					{
						ghostUnscareAlarm.play();
						unscarePlay = true;
					}
					if(unscarePlay)
					{
						scareAlarmCount++;
					}	
					if(scareAlarmCount == 120)
					{
						unscarePlay = false;
						scareAlarmCount = 0;
					}
				}	
			}
		}
	}	
	//Resets the ghosts after pellet use
	public void resetGhosts()
	{
		if(ghostsRespawning)
		{
			if(inkMunched)
			{
				if(spawnTime == 1)
				{
					inkMunched = false;
					inkyX = 275;
					inkyY = 275;
					inkyXSpeed = 2;
					inkyYSpeed = -2;
				}
			}
			if(pinkMunched)
			{
				if(spawnTime == 2)
				{
					pinkMunched = false;
					pinkyX = 275;
					pinkyY = 275;
					pinkyXSpeed = -2;
					pinkyYSpeed = 2;
				}
			}
			if(blinkMunched)
			{
				if(spawnTime == 3)
				{
					blinkMunched = false;
					blinkyX = 275;
					blinkyY = 275;
					blinkyXSpeed = 2;
					blinkyYSpeed = 2;
				}
			}
			if(clydeMunched)
			{
				if(spawnTime == 4)
				{
					clydeMunched = false;
					clydeX = 275;
					clydeY = 275;
					clydeXSpeed = -2;
					clydeYSpeed = -2;
				}
			}
		}
	}
	//Runs the game
	public void paint(Graphics art)
	{
		setSize(600,600);
		setBackground(Color.gray);
		if(showStart)
		{
			startScreen(art);
		}
		if(playGame)
		{
			startMusic();
			bgm();
			drawArena(art);
			drawPacman(art);
			drawDot1(art);
			drawDot2(art);
			drawDot3(art);
			drawDot4(art);
			drawPP(art);
			drawFruit(art);
			drawInky(art);
			drawPinky(art);
			drawBlinky(art);
			drawClyde(art);
			collision();
			timer();
			resetGhosts();
		}
		if(gameOver)
		{
			endScreen(art);
		}
		repaint();
	}
	//Gets key inputs
	public void keyPressed(KeyEvent e)
	{
		int key = e.getKeyCode();
		if(key == e.VK_UP)
		{
			dir = 90;
			upDown = true;
			goUp = true;
			pacXspeed = 0;
			startMovement = true;
		}
		if(key == e.VK_DOWN)
		{
			dir = 270;
			upDown = true;
			goUp = false;
			pacXspeed = 0;
			startMovement = true;
		}
		if(key == e.VK_RIGHT)
		{
			dir = 0;
			upDown = false;
			goRight = true;
			pacYspeed = 0;
			startMovement = true;
		}
		if(key == e.VK_LEFT)
		{
			dir = 180;
			upDown = false;
			goRight = false;
			pacYspeed = 0;
			startMovement = true;
		}
		//Game settings inputs
		if(key == e.VK_ENTER)
		{
			if(showStart)
			{
				showStart = false;
				playGame = true;
			}
		}
		if(key == e.VK_S)
		{
			if(!showHitBoxes)
			{
				showHitBoxes = true;
			}
		}
		if(key == e.VK_D)
		{
			if(showHitBoxes)
			{
				showHitBoxes = false;
			}
		}
	}
	public void keyReleased(KeyEvent arg0)
	{
	}
	public void keyTyped(KeyEvent arg0)
	{
	}
}